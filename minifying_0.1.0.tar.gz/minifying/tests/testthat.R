library(testthat)
library(minifying)

test_check("minifying")
